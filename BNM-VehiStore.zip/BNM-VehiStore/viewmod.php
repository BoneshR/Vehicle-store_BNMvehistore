<?php
 
include_once("connect.php");

 $result = mysqli_query($mysqli, "SELECT * FROM vehicles ORDER BY vid DESC"); 
//$result = mysqli_query($mysqli, "SELECT * FROM vehicles WHERE vbrands LIKE '%maruthi%' || vtype LIKE '%2%' "); 
?>

<html>
<head>	
	
<head>
	<title>Add Data</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">


    <style>
        body {
            font-family: "System", Times, serif;
            color: #777;
            background-image:url("bg..png");

            background-size:cover;
            }
            h5{
            margin: 0 0 0 20px;
            letter-spacing: 1px;      
            font-size: 20px;
            color: #111;
            background-color:"#F08080";
            }
            .container {
            padding: 80px 120px;
            }
            .person {
            border: 10px solid transparent;
            margin-bottom: 25px;
            opacity: 0.7;
            }
            .person:hover {
            border-color: #f1f1f1;
            }
            .text-center{
            color: #ff0000 !important;
            }
            .carousel-inner img {
            width: 100%;  
            margin: auto;
            }
            .carousel-caption h3 {
            color: #ff0000 !important;
            }
            @media (max-width: 600px) {
            .carousel-caption {
            display: none; 
            }
            }
              .btn {
                  padding: 3px 5px;
                  transition: .2s;
              font-size: 15px !important;
                float: right;
              }
              .btn:hover, .btn:focus {
                  border: 1px solid #111;
                  background-color: black;
                  color: white;
              }
            .w3-container{
            color: white;
              }	
            
                .navbar {
                font-family: "System", Times, serif;
                  margin-bottom: 0;
              
                  border: 0;
                  font-size: 15px !important;
                  letter-spacing: 1px;
                  opacity: 0.9;
                }
              .navbar li a, .navbar .navbar-brand { 
                  color: #fff !important;
              }
                .navbar-nav li a:hover {
                  color: #000 !important;
              }
                .navbar-nav li.active a {
                  color: #000 !important;
                
              }
              .navbar-default .navbar-toggle {
                  border-color: transparent;
              }
            .nav-item-dropdown{
            color:#000;
            }
              footer {
                      background-color: #fc036b ;
            border-color: transparent;
            padding:2px;
              }
              footer a {
                  color:black;
              }
              footer a:hover {
                  color:white;
                  text-decoration: none;
              }  
              .form-control {
                  border-radius: 2;
              }
            #navdrop , .dropdown-menu{
            background-color: #38f084;
            }
            tr{
            background-color:white;
            text-align:center;
            border:3px solid #38f084;
            }
            td{
            border:3px solid #38f084;
            color:black;
            }

         </style>
           
        
       
        
         
       <body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="50">

       <nav class="navbar navbar-expand-lg navbar-dark "  style="background-color:blue;" >
          <a class="navbar-brand" href="top">
            <img src="http://localhost:8080/BNM-VehiStore/logo1.png" height="45px" width="45px"  alt="">&nbsp&nbsp<b style="font-size:30px">BNM VehiStore</b>   
          </a>
          <a style="margin: 1%1%1%72%;background-color:rgb(8, 8, 8); " href="http://localhost:8080/BNM-VehiStore/logout.jsp" class="btn btn-danger btn-lg active" role="button" data-toggle="popover" title="Login/Signup" data-content="Login/Signup" aria-pressed="true">Logout</a>
	      </nav>
       
       
        <nav class="navbar navbar-expand-lg navbar-light sticky-top "  style="background-color:#38f084;" >
          <div class="collapse navbar-collapse " id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                    
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Models
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class=" dropdown-item" id="navdrop" href="http://localhost/BNM-VehiStore/addmod.html">Add Models</a>
                    <a class="dropdown-item"  id="navdrop" href="http://localhost/BNM-VehiStore/viewmod.php">View Models</a>
                </div>
              </li>

              <li class="nav-item active ">
                <a class="nav-link " href="http://localhost:8080/BNM-VehiStore/adminhome.jsp"><b>Home</b> 
                  <span class="sr-only">(current)</span></a>
              </li>

            </ul>
          </div>
        </nav>
</head>
 


<body>
 

	<table style="width:100%;background-color:grey;border:2px solid blue;">

	<tr style="background-color:grey;">
    <td style="color:white;font-size:30px;border:1px solid black;">V-ID</td>
    <td style="color:white;font-size:30px;border:1px solid black;">Type</td>       
    <td style="color:white;font-size:30px;border:1px solid black;">Brand</td>
		<td style="color:white;font-size:30px;border:1px solid black;">Model</td>
		<td style="color:white;font-size:30px;border:1px solid black;">Status</td>
		<td style="color:white;font-size:30px;border:1px solid black;">Price</td>
		<td style="color:white;font-size:30px;border:1px solid black;">Mileage</td>
		<td style="color:white;font-size:30px;border:1px solid black;">Seats</td>
		<td style="color:white;font-size:30px;border:1px solid black;">Image</td>
	</tr>
	<?php 
	 
   while($res = mysqli_fetch_assoc($result)) 
	{ 		
		echo "<tr>";
    echo "<td><b>".$res['vid']."</b></td>";
    echo "<td><b>".$res['vtype']."</b></td>";
		echo "<td><b>".$res['vbrands']."</b></td>";
		echo "<td><b>".$res['vmodel']."</b></td>";
		echo "<td><b>".$res['vstatus']."</b></td>";
        	echo "<td><b>".$res['vprice']."</b></td>";
        	echo "<td><b>".$res['vmileage']."</b></td>";
        	echo "<td><b>".$res['vseating']."</b></td>";?>
                <td><img src="<?php echo $res['vimage']; ?>" width="200" height="100"></td></tr>
		 <?php
        	 	
		 
	}
	?>
	</table>
 
<footer class="text-center">
    <h6 style="color: #f1f1f1;">Bonesh R - 1BG19CS402<h6> 
  </footer>
  
  <script language=JavaScript>
  $(function () {
    $('[data-toggle="popover"]').popover()
  })
  </script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  
</body>
</html>