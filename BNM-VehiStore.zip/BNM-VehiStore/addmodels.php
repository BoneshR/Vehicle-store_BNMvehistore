<html>
<head>
	<title>Add models</title>
</head>

<body>
<?php
 
include_once("connect.php");

if(isset($_POST['Submit'])) {	
	$typ = mysqli_real_escape_string($mysqli, $_POST['type']);
	$brand = mysqli_real_escape_string($mysqli, $_POST['brands']);
	$mod = mysqli_real_escape_string($mysqli, $_POST['model']);
	$stat = mysqli_real_escape_string($mysqli, $_POST['status']);
	$pri = mysqli_real_escape_string($mysqli, $_POST['price']);
	$mile = mysqli_real_escape_string($mysqli, $_POST['mileage']);
	$seat = mysqli_real_escape_string($mysqli, $_POST['seating']);
	$img = mysqli_real_escape_string($mysqli, $_POST['image']);

	 
	if(empty($brand)) {
				
		if(empty($brand)) {
			echo "<font color='red'>Brand field is empty.</font><br/>";
		}
		 
		
		 
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
			
		 	
		$result = mysqli_query($mysqli, "INSERT INTO vehicles (vtype,vbrands,vmodel,vstatus,vprice,vmileage,vseating,vimage) VALUES('$typ','$brand','$mod','$stat','$pri','$mile','$seat','$img')");
		
		 
		?><center> <script>
		alert("Data successfully submitted!");
		location.reload();
		window.location = "http://localhost:8080/BNM-VehiStore/adminhome.jsp";
	</script>
		<?php
	}
}
?>

</body>
</html>