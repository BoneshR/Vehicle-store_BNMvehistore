-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2021 at 04:10 PM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adj`
--

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `vid` int(3) NOT NULL,
  `vtype` varchar(50) NOT NULL,
  `vbrands` varchar(50) NOT NULL,
  `vmodel` varchar(50) NOT NULL,
  `vstatus` varchar(20) NOT NULL,
  `vprice` varchar(10) NOT NULL,
  `vmileage` varchar(10) NOT NULL,
  `vseating` varchar(10) NOT NULL,
  `vimage` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`vid`, `vtype`, `vbrands`, `vmodel`, `vstatus`, `vprice`, `vmileage`, `vseating`, `vimage`) VALUES
(1, '4 Wheeled', 'AUDI', 'A6', 'New', '58 lakh', '21', '5', 0x417564692041362e706e67),
(2, '4 Wheeled', 'Maruthi Suzuki', 'Wagon R', 'New', '6 lakh', '28', '4', 0x4d6172757469205761676f6e20522e706e67),
(3, '2 Wheeled', 'Royal Enfield', 'Classic 350', 'New', '1.89 lakh', '41', '2', 0x52452d3330302e706e67),
(4, '4 Wheeled', 'Volkswagen', 'Polo', 'Up Coming', '6-9 lakh', '18', '4', 0x566f6c6b73776167656e20506f6c6f2e706e67),
(6, '2 Wheeled', 'Harley davidson', 'Fat BOB', 'Up Coming', '17 lakh', '20', '2', 0x4861726c6579204461766964736f6e2046617420426f622e706e67),
(7, '4 Wheeled', 'Toyota', 'Innova Crysta', 'New', '17.56 lakh', '21', '7', 0x4d4720486563746f722e706e67),
(8, '2 Wheeled', 'BMW', 'RR', 'New', '20 lakhs', '21', '2', 0x424d57205320313030302052522e706e67);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`vid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `vid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
